package E1;

public class Cliente extends Persona {
    int idCliente;
    int montoCredito;

    public Cliente(int idCliente, int montoCredito, int nroCedula, String nombre, String apellido, int edad) {
        super(nroCedula, nombre, apellido, edad);
        this.idCliente = idCliente;
        this.montoCredito = montoCredito;
    }
}

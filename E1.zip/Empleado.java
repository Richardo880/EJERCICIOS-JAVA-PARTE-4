package E1;

public class Empleado extends Persona {
    protected int idEmpleado;
    protected int salario;

    public Empleado(int idEmpleado, int salario, int nroCedula, String nombre, String apellido, int edad) {
        super(nroCedula, nombre, apellido, edad);
        this.idEmpleado = idEmpleado;
        this.salario = salario;
    }
    
    @Override
    public void visualizar () {
        super.visualizar();
        System.out.println("Id: \t\t\t" + idEmpleado);
        System.out.println("Salario : \t\t\t" + salario);
    }
}

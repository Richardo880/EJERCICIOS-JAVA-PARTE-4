package E1;

public class Pruebas {
    public static void main (String [] agrs) {
        Persona pe = new Persona(7654321, "Juan", "De los Pelotes", 34);
        
        Empleado em = new Empleado(1, 2000000, 6475832, "David", "Martinex", 22);
        
        Cliente cl = new Cliente(1, 200000, 6857453, "Javi", "Lopez", 56);
            
        pe.visualizar();
        em.visualizar();
        cl.visualizar();
    }
}

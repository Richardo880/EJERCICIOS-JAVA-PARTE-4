package E1;

public class Persona {
    protected int nroCedula;
    protected String nombre;
    protected String apellido;
    protected int edad;

    public Persona(int nroCedula, String nombre, String apellido, int edad) {
        this.nroCedula = nroCedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    public void visualizar () {
        System.out.println("Visualizando");
        System.out.println("Cedula: \t\t\t" + nroCedula);
        System.out.println("Nombre: \t\t\t" + nombre);
        System.out.println("Apellido: \t\t\t" + apellido);
        System.out.println("Edad: \t\t\t" + edad);
    }
}

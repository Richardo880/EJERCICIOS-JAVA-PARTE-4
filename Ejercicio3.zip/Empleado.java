
public class Empleado {
    protected String nombre;
    protected String apellido;
    protected int nroCedula;
    protected String cargo;
    protected int horas_trabajadas;

    public Empleado(){     
    }
    
    public Empleado(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nroCedula = nroCedula;
        this.cargo = cargo;
        this.horas_trabajadas = horas_trabajadas;
    }

    
    public boolean acceso_publico(){
        if(this.cargo.equals("Vendedor")|| this.cargo.equals("Atencion al Cliente"))
            return true;
        return false;
    }
    public boolean acceso_admin(){
        if(this.cargo.equals("Gerente")|| this.cargo.equals("Jefe de Nomina"))
            return true;
        return false;
    }

    @Override
    public String toString() {
        return String.format("%s: %s%n%s: %s%n%s: %d%n%s: %s%n","Nombre",nombre,
                                                              "Apellido",apellido,
                                                              "CI",nroCedula,
                                                              "Cargo",cargo);
    }
    
    
    
}

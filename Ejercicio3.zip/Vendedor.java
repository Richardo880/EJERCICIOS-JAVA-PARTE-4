
public class Vendedor extends Operario{
    protected double totalVentas;

    public Vendedor(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas, double totalVentas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas);
        this.totalVentas = totalVentas;
    }

    public double getTotalVentas() {
        return totalVentas;
    }
    
    @Override
    public String toString() {
        return String.format("%s%n",super.toString());
    }
    
}

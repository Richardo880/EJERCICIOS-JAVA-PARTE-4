
public class Operario extends Empleado {

    public Operario(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas);
    }
     
    public double getHoras_trabajadas() {
        return super.horas_trabajadas;
    }  
    
}


public class Nomina extends Directivo {
    protected double salario_actual = 2550307;

    public Nomina(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas, int reuniones_programadas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas, reuniones_programadas);
    }
 
    public double calcular_salarios(int horas){
        return this.salario_actual*horas;
    }
    
    public double calcular_aumento(int horas){
        if(horas > 40){
            this.salario_actual += 100000;
        }
        return this.salario_actual;
    }
    
    public double calcular_primas(int horas){
        return (this.salario_actual*(horas/24))/360;
    }
    
    @Override
    public String toString() {
        return String.format("%s%n",super.toString());
    }
    
    
}


import java.util.ArrayList;

public class PruebaEmpleado {

    public static void main(String[] args) {
        ArrayList<Empleado> empleados = new ArrayList<Empleado>();
        Gerente ge = new Gerente("Jonathan","Godoy",5432109,"Gerente",3500,10);
        Nomina nm = new Nomina("Yulissa","Martinez",6543219,"Jefe de Nomina",4000,3);
        Vendedor vd = new Vendedor("Francisco","Perez",7865123,"Vendedor",6000,10000000.000 );
        AtencionCliente ac = new AtencionCliente("Marcos","Villa",7327543,"Atencion al Cliente",2000);
        
        empleados.add(ge);
        empleados.add(nm);
        empleados.add(vd);
        empleados.add(ac);
        
        if(ge.acceso_admin()){
            ge.visualizar(empleados);
            System.out.println();
        }else{
            System.out.println("No tiene permisos");
        }
        if(nm.acceso_admin()){
            System.out.printf("Calculo de primas: %.2f\n",nm.calcular_primas(2000));
        }else{
            System.out.println("No tiene permisos");
        }
        
        if(!vd.acceso_admin()){
            System.out.println("No tienes permisos administrativos");
        }       
        System.out.printf("Ventas Totales: %.2f\n",vd.getTotalVentas());
        
        ac.atender_reclamaciones(2);
        
    }
    
}

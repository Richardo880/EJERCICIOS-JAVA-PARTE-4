
public class Directivo extends Empleado {
    protected int reuniones_programadas;

    public Directivo(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas, int reuniones_programadas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas);
        this.reuniones_programadas = reuniones_programadas;
    }

    public int getReuniones() {
        return reuniones_programadas;
    }

    public void setReuniones(int reuniones_programadas) {
        this.reuniones_programadas = reuniones_programadas;
     }
}


import java.util.ArrayList;


public class Gerente extends Directivo{   

    public Gerente(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas, int reuniones_programadas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas, reuniones_programadas);
    }
  

    @Override
    public boolean acceso_admin() {
        return super.acceso_admin(); 
    }
    
    public void visualizar(ArrayList empleados){
        for(int i = 0; i < empleados.size(); i++)
            System.out.print(empleados.get(i));
    }

    @Override
    public String toString() {
        return String.format("%s%n",super.toString());
    }
    
    
    
}

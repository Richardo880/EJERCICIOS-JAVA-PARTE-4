
public class AtencionCliente extends Operario {
    
    public AtencionCliente(String nombre, String apellido, int nroCedula, String cargo, int horas_trabajadas) {
        super(nombre, apellido, nroCedula, cargo, horas_trabajadas);
    }
    
    public void atender_reclamaciones(int atencion){
        switch(atencion){
            case 1:
                System.out.println("Llamada telefonica del cliente para un reclamo");
                break;
            case 2:
                System.out.println("Mensaje online del cliente para un reclamo");
                break;
            case 3:
                System.out.println("Cliente en la recepcion para un reclamo");
                break;
        }
    }
    @Override
    public String toString() {
        return String.format("%s%n",super.toString());
    }
}
